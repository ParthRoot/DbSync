import { M2MContractHistory } from './M2MContractHistory.entity';

export const entities = [M2MContractHistory];

export * from './M2MContractHistory.entity';
