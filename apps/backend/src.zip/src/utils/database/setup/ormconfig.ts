import { cloudTypeOrmConfig, logger, typeOrmConfig } from '../../index';

logger.log(typeOrmConfig);
logger.log(cloudTypeOrmConfig);
