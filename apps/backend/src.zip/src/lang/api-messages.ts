export const messages = {
    tokenExpires: 'Token expired.',
    unableToVerifyDb: 'Unable to verify database connection.',
};
